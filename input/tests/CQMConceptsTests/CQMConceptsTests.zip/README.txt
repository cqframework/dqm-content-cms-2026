The purpose of this file is to allow users to view the mapping of test case names to their test case UUIDs. In order to find a specific test case file in the export, first locate the test case name in this document and then use the associated UUID to find the name of the folder in the export.

Case # 1 - 8a611c20-2ff6-4c60-9a61-98420dafe057 =  01-Value-Set-Encounters
Case # 2 - fc1cccc7-2133-4ab6-a58a-0df6ce5d4fd6 =  02-No-Encounters