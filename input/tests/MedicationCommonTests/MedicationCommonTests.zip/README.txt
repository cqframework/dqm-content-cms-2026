The purpose of this file is to allow users to view the mapping of test case names to their test case UUIDs. In order to find a specific test case file in the export, first locate the test case name in this document and then use the associated UUID to find the name of the folder in the export.

Case # 1 - 13f360fc-0f4e-4aeb-b4a2-f203114d0ca3 =  06-Administration-Category
Case # 2 - 1f1ce5cf-3110-454e-973c-6dd0bf9e8e47 =  03-Request-Category
Case # 3 - 40cdcb61-ef2f-4a7c-91c5-633ec79c2fea =  05-Administration-Status
Case # 4 - 8adc9a27-2c9c-47ae-8999-ffab80a7d591 =  02-Request-Intent
Case # 5 - 9294f0b2-0626-41fd-84b3-39f59ac85304 =  01-Request-Status
Case # 6 - b06e66e8-f1c4-4a5d-8f16-a954f808908c =  07-Dispense-Status
Case # 7 - cba06702-46a6-4cc0-9d03-2bda23229a96 =  04-Request-Most-Recent
Case # 8 - f03b022c-d1ac-4916-af3e-cda72e39dc02 =  09-No-Medications
Case # 9 - f710f472-4961-4c25-9e14-e706af5e2fe9 =  08-Negation-Profiles