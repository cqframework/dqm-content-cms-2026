The purpose of this file is to allow users to view the mapping of test case names to their test case UUIDs. In order to find a specific test case file in the export, first locate the test case name in this document and then use the associated UUID to find the name of the folder in the export.

Case # 1 - 030999a1-6dc3-4baa-b36a-0d3dfb2d0e7a =  02-Two-Items-Two-Encounters
Case # 2 - 041bd642-2389-4a74-8ab0-279d824a38ad =  04-Related-By-Date
Case # 3 - 0d2d9432-a6a5-40a1-8108-433afb66dc16 =  01-Inpatient-Claim
Case # 4 - 662c1084-2f33-4556-be36-7c000335514d =  05-No-Claims
Case # 5 - 973bdec0-2ce7-4138-8de9-e113a3ca2981 =  03-Status-And-Use