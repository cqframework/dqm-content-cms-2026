The purpose of this file is to allow users to view the mapping of test case names to their test case UUIDs. In order to find a specific test case file in the export, first locate the test case name in this document and then use the associated UUID to find the name of the folder in the export.

Case # 1 - 01-Inpatient-Claim =  01-Inpatient-Claim
Case # 2 - 02-Two-Items-Two-Encounters =  02-Two-Items-Two-Encounters
Case # 3 - 03-Status-And-Use =  03-Status-And-Use
Case # 4 - 04-Related-By-Date =  04-Related-By-Date
Case # 5 - 05-No-Claims =  05-No-Claims