The purpose of this file is to allow users to view the mapping of test case names to their test case UUIDs. In order to find a specific test case file in the export, first locate the test case name in this document and then use the associated UUID to find the name of the folder in the export.

Case # 1 - 29c6dee9-b918-4f79-8146-8bcd971559e7 =  02-Dispense-Medication-Forms
Case # 2 - 52a9747a-63de-4745-a59f-6ddf0a904345 =  04-Shared-Medications
Case # 3 - 586c4166-8b7b-4063-8f29-cbe7259b762a =  03-Administration-Medication-Forms
Case # 4 - cefac7d4-207f-4bc4-9d90-07eb4adbb2b1 =  01-Request-Medication-Forms
Case # 5 - e79e6f21-5465-4608-9154-cc46f4db51df =  05-No-Medications