The purpose of this file is to allow users to view the mapping of test case names to their test case UUIDs. In order to find a specific test case file in the export, first locate the test case name in this document and then use the associated UUID to find the name of the folder in the export.

Case # 1 - 351b809a-611a-4560-8268-4bc4339cd1ff =  01-ED-Observation-Inpatient
Case # 2 - 76dcbe31-5d57-4ecf-9a01-d11e38c85765 =  05-Gap-Exactly-One-Hour
Case # 3 - 9b355d5a-4e47-44fc-851a-77e98e2c9926 =  03-Surgery-Inpatient
Case # 4 - c5bc7aa4-968e-4774-a409-53c440af64fb =  04-Cancelled-ED-Inpatient
Case # 5 - d25d47ed-a786-465b-8e59-c8b980029766 =  08-No-Encounters
Case # 6 - de9e218e-639b-4f12-917b-2aa3c3ce3f2d =  07-Inpatient-Two-ICU-Stays
Case # 7 - e31c1934-2e12-4fcd-bf12-c2906b73ed43 =  06-Gap-One-Hour-One-Minute
Case # 8 - e73944d1-223b-425f-8082-67374ae54efc =  02-ED-Inpatient-Gap-Over-Hour