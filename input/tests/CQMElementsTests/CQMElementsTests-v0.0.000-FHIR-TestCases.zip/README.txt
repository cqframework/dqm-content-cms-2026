The purpose of this file is to allow users to view the mapping of test case names to their test case UUIDs. In order to find a specific test case file in the export, first locate the test case name in this document and then use the associated UUID to find the name of the folder in the export.

Case # 8 - e73944d1-223b-425f-8082-67374ae54efc =  02-ED-Inpatient-Gap-Over-Hour