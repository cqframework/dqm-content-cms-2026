The purpose of this file is to allow users to view the mapping of test case names to their test case UUIDs. In order to find a specific test case file in the export, first locate the test case name in this document and then use the associated UUID to find the name of the folder in the export.

Case # 1 - 0bb111d7-a019-44ff-b000-9b8a1ead100f =  12-HOB-Day-6
Case # 2 - 19c0c6e3-766f-4f72-8519-9b6a3c55db5d =  07-ED-Inpatient-Gap-Over-Hour
Case # 3 - 42932e7a-46e8-4134-8852-327a2fe42216 =  16-HOB-Non-Matching-COB
Case # 4 - 56050d88-794a-4c23-8564-bab422172805 =  14-Day-3-COB-Day-4-HOB
Case # 5 - 5ad284c0-90fa-4953-9650-4fc4324c7e0f =  03-OBS-Only
Case # 6 - 608a829f-3237-476e-affa-bc8a85f83e9d =  11-COB-Window-Before-MP
Case # 7 - 64eab3ff-d208-4eab-a28d-528e2b68907c =  08-Discharged-Day-3
Case # 8 - 6a2768ee-b9d5-4a84-9a28-0aafc39a1703 =  18-Day-Count-From-ED-Arrival
Case # 9 - 745c7428-d787-493c-8652-5af34a811f97 =  21-No-Specimen
Case # 10 - 89bd67c0-37dd-48a7-a222-4cc86ad358fa =  05-OBS-Inpatient
Case # 11 - 97322a7c-8ef2-49d1-a863-bf96626f1996 =  09-Discharged-Day-4
Case # 12 - 98a2bca8-4fa8-41a8-bb93-98c872e4c155 =  13-COB-Day-2
Case # 13 - a78d7577-d2cf-4741-9464-e5480af48f8a =  04-ED-OBS-O-COB
Case # 14 - c3c71a9a-f6dd-4efd-adf8-0417ad5ba727 =  19-Excluded-Results
Case # 15 - d11a20b3-f05f-4cd3-abd2-e10c8eccaafc =  23-No-Encounters
Case # 16 - d29ac01e-09dc-4b39-9404-6ac61ec66e0e =  10-Culture-After-Discharge
Case # 17 - e0dcc8d7-cc79-4a51-b516-6630ff02574d =  22-Prior-HOB-Before-MP
Case # 18 - e24d9924-bf2a-4348-8024-25c890e95568 =  06-ED-Inpatient-Culture-In-ED
Case # 19 - e69774f5-3cec-43d4-8a1f-06724d9836fa =  01-ED-Only
Case # 20 - eec30a27-3635-4cd9-abab-62f2fe47ef46 =  15-HOB-Excluded-Matching-COB
Case # 21 - f2b6ce03-5652-4bb9-a50b-762c201549c1 =  17-HOB-Excluded-Genus-Match
Case # 22 - f47dd828-63b0-499a-8e4b-571c60ea34d6 =  02-ED-Outside-MP
Case # 23 - fca52ba3-d56d-4e38-a9fc-2cab1a726b9d =  20-Specimen-Collection-Time